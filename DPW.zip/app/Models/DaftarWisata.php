<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class DaftarWisata extends Model
{
    

    protected $table = 'daftar_wisata';


    

    
}
