<!-- packages.blade.php -->
<?php
    use App\Models\DaftarWisata;
?>



<?php $__env->startSection('title', 'Packages'); ?>

<?php $__env->startSection('content'); ?>

<!-- ***** Call to Action Start ***** -->
<section class="section section-bg" id="call-to-action" style="background-image: url(assets/images/banner-image-1-1920x500.jpg)">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <div class="cta-content">
                    <br>
                    <br>
                    <h2>Paket <em>Tersedia</em></h2>
                    <p>Daftar tempat wisata terbaik di Banyumas</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ***** Call to Action End ***** -->

<!-- ***** Fleet Starts ***** -->
<section class="section" id="trainers">
    <div class="container">
        <br>
        <br>

        <div class="row">
            <?php $__currentLoopData = $daftarWisatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftarWisata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="trainer-item">
                    <div class="image-thumb">
                        <img src="<?php echo e(asset('uploads/' . $daftarWisata->gambar), false); ?>" alt="<?php echo e($daftarWisata->nama_wisata, false); ?>">
                    </div>
                    <div class="down-content">
                        <span>
                            <sup>Rp</sup><?php echo e($daftarWisata->min_harga, false); ?> - <sup>Rp</sup><?php echo e($daftarWisata->max_harga, false); ?>

                        </span>

                        <h4><?php echo e($daftarWisata->nama_wisata, false); ?></h4>

                        <p>
                            <i class="fa fa-calendar"></i> <?php echo e($daftarWisata->musim, false); ?> &nbsp;&nbsp;&nbsp;

                            <i class="fa fa-cube"></i> <?php echo e($daftarWisata->durasi_malam, false); ?> nights &nbsp;&nbsp;&nbsp;

                            <i class="fa fa-plane"></i> <?php echo e($daftarWisata->penerbangan ? 'Flight included' : 'No Flight', false); ?> &nbsp;&nbsp;&nbsp;
                        </p>

                        <ul class="social-icons">
                            <li><a href="https://wa.me/082325085612", target="blank">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <br>

        <nav>
            <ul class="pagination justify-content-center">
                <?php if($daftarWisatas->previousPageUrl()): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($daftarWisatas->previousPageUrl(), false); ?>" aria-label="Previous">
                            <span aria-hidden="true"><i class="fas fa-chevron-left"></i></span>
                        </a>
                    </li>
                <?php endif; ?>

                <li class="page-item disabled">
                    <span class="page-link">Page <?php echo e($daftarWisatas->currentPage(), false); ?> of <?php echo e($daftarWisatas->lastPage(), false); ?></span>
                </li>

                <?php if($daftarWisatas->nextPageUrl()): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($daftarWisatas->nextPageUrl(), false); ?>" aria-label="Next">
                            <span aria-hidden="true"><i class="fas fa-chevron-right"></i></span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>


    </div>
</section>
<!-- ***** Fleet Ends ***** -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\babylinn\Desktop\DPW\resources\views/halaman/packages.blade.php ENDPATH**/ ?>