<!-- footer.blade.php -->

<footer>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p>
                    Copyright © 2020 Company Name
                    - Template by: <a href="https://www.phpjabbers.com/">PHPJabbers.com</a>
                </p>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\babylinn\Desktop\DPW\resources\views/partials/footer.blade.php ENDPATH**/ ?>