<!-- header.blade.php -->

<header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <a href="/" class="logo">Purwoker<em> Tour</em></a>

                    <ul class="nav">
                        <li><a href="/" class="<?php echo e(Request::is('/') ? 'active' : '', false); ?>">Home</a></li>
                        <li><a href="/packages" class="<?php echo e(Request::is('packages') ? 'active' : '', false); ?>">Packages</a></li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">About</a>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="/about">About Us</a>
                                <a class="dropdown-item" href="/testimonials">Testimonials</a>
                                <a class="dropdown-item" href="/terms">Terms</a>
                            </div>
                        </li>
                        <li><a href="/contact" class="<?php echo e(Request::is('contact') ? 'active' : '', false); ?>">Contact</a></li>
                        <li><a href="/admin" class="<?php echo e(Request::is('admin') ? 'active' : '', false); ?>">Admin</a></li>
                    </ul>

                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                </nav>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\Users\babylinn\Desktop\DPW\resources\views/partials/header.blade.php ENDPATH**/ ?>